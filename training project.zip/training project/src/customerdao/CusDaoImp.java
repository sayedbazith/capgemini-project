package customerdao;






import java.sql.Timestamp;
import java.util.ArrayList;

import java.util.List;


import customerbean.CusBean;

public class CusDaoImp implements CusDao 
{
	double bal;
	boolean valid=false;
	int value;
	String str=null;
	List<CusBean> list=new ArrayList<CusBean>();
	List<CusBean> trans=new ArrayList<CusBean>();
	
	CusBean b=null;
	CusBean tr=new CusBean();
	@Override
	public CusBean createAccount(CusBean c)
	{
		// TODO Auto-generated method stub
		Timestamp time=new Timestamp(System.currentTimeMillis());
		String instantString=time.toString();
		list.add(c);
		c.setTranscationdeposit(0);
		c.setTranscationwithdrawl(0);
		c.setTime(instantString);
		trans.add(c);
		return c;
	}

	@Override
	public CusBean showBalance(int id) 
	{
		// TODO Auto-generated method stub
	
			for (CusBean cusBean : list) 
			{
				if(id==cusBean.getCusid())
				{
					b=cusBean;
					break;
				}
				else
					b=null;
			}
		return b;
	}

	@Override
	public CusBean Deposit(int id, double amount) 
	{
		// TODO Auto-generated method stub
		Timestamp time=new Timestamp(System.currentTimeMillis());
		String instantString=time.toString();
		for (CusBean cusBean : list) 
		{
			if(id==cusBean.getCusid())
			{
				bal=cusBean.getBalance()+amount;
				cusBean.setBalance(bal);
				cusBean.setTranscationdeposit(amount);
				cusBean.setTranscationwithdrawl(0);
				cusBean.setTime(instantString);
				b=cusBean;
				break;
			}
			else
				b=null;
			trans.add(cusBean);
		}
		
		return b;
	}

	@Override
	public CusBean withDraw(int id, double amount) 
	{
		// TODO Auto-generated method stub
		Timestamp time=new Timestamp(System.currentTimeMillis());
		String instantString=time.toString();
		for (CusBean cusBean : list) 
		{
			if(id==cusBean.getCusid())
			{
				bal=cusBean.getBalance()-amount;
				if(bal>=0)
				{	
					cusBean.setBalance(bal);
					b=cusBean;
					cusBean.setTranscationwithdrawl(amount);
					cusBean.setTranscationdeposit(0);
					cusBean.setTime(instantString);
					trans.add(cusBean);
					System.out.println("withdrawl success");
					break;
				}
				else
				{
					System.out.println("no funds");
					b=cusBean;
				}
				break;
			}
			else
				b=null;
		}
		return b;
	}

	@Override
	public boolean fundTransfer(int id, double amount) 
	{
		// TODO Auto-generated method stub
		/*Timestamp time=new Timestamp(System.currentTimeMillis());
		String instantString=time.toString();*/
		for (CusBean cusBean : list) 
		{
			if(id==cusBean.getCusid())
			{
				if(amount>0)
				{
					double balance=amount+cusBean.getBalance();
					cusBean.setBalance(balance);
					System.out.println(cusBean);
					/*cusBean.setTranscationdeposit(0);
					tr.setTranscationwithdrawl(amount);
					tr.setTime(instantString);*/
					/*trans.add(cusBean);*/
					valid=true;
				}
			}
			else
				valid=false;
		}		
		return valid;
	}
	@Override
	public boolean printTranscations(int id) 
	{
		// TODO Auto-generated method stub
		for (CusBean cusBean : trans) 
		{
				System.out.println(cusBean);
		}
		
				return false;
	}
}
