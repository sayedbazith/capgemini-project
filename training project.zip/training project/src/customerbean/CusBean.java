package customerbean;

public class CusBean 
{
	private String cusname;
	private int cusage;
	private int cusid;
	private double balance;
	private double deposit;
	private double withdrawl;
	private double transcationdeposit;
	private double transcationwithdrawl;
	private String time;
	
	public double getTranscationdeposit() {
		return transcationdeposit;
	}
	public void setTranscationdeposit(double transcationdeposit) {
		this.transcationdeposit = transcationdeposit;
	}
	public double getTranscationwithdrawl() {
		return transcationwithdrawl;
	}
	public void setTranscationwithdrawl(double transcationwithdrawl) {
		this.transcationwithdrawl = transcationwithdrawl;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

	
	
	public double getDeposit() 
	{
		return deposit;
	}
	public void setDeposit(double deposit)
	{
		this.deposit = deposit;
	}
	public double getWithdrawl() {
		return withdrawl;
	}
	public void setWithdrawl(double withdrawl) 
	{
		this.withdrawl = withdrawl;
	}

	public double getBalance()
	{
		return balance;
	}
	public void setBalance(double balance) 
	{
		this.balance = balance;
	}
	
	public String getCusname()
	{
		return cusname;
	}
	public void setCusname(String cusname) 
	{
		this.cusname = cusname;
	}
	public int getCusage() 
	{
		return cusage;
	}
	public void setCusage(int cusage) 
	{
		this.cusage = cusage;
	}
	public int getCusid()
	{
		return cusid;
	}
	public void setCusid(int cusid) 
	{
		this.cusid = cusid;
	}
	@Override
	public String toString() {
		return "CusBean [cusname=" + cusname + ", cusage=" + cusage
				+ ", cusid=" + cusid + ", balance=" + balance + ", deposit="
				+ deposit + ", withdrawl=" + withdrawl
				+ ", transcationdeposit=" + transcationdeposit
				+ ", transcationwithdrawl=" + transcationwithdrawl + ", time="
				+ time + "]";
	}
	
	
}
