package customerservice;

import customerbean.CusBean;

public interface CusService 
{
	public boolean validate(CusBean c);
	public CusBean createAccount(CusBean c);
	public CusBean showBalance(int id);
	public CusBean Deposit(int id,double amount);
	public CusBean withDraw(int id,double amount);
	public boolean fundTransfer(int id,double amount);
	public boolean printTranscations(int id);
	
}
