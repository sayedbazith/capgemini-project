package customertest;

import static org.junit.Assert.*;

import org.junit.Test;  

import customerbean.CusBean;
import customerservice.CusService;
import customerservice.CusServiceImp;

public class CusDaoImpTest {

	CusService cus=new CusServiceImp();
	CusBean bean=new CusBean();
	/*@Test
	public void testCreateAccount() {
		fail("Not yet implemented");
	}*/

	
	@Test
	public void testShowBalance()
	{
		double expected=2424.54;
		double actual=bean.getBalance();
		assertEquals(expected, actual);
	}

	

	

	/*@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithDraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTranscations() {
		fail("Not yet implemented");
	}
*/
}
